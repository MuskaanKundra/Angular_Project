import { Component,OnInit } from '@angular/core';

@Component ({
    selector: 'app-employee',
    templateUrl: './employee.component.html' ,
    styleUrls: ['./employee.component.css']
})

export class EmployeeComponent implements OnInit {
Name: string="Muskaan Kundra";

ID:number=123;

constructor() { }
ngOnInit():void {
    }
} 